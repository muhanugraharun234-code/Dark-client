package com.darkclient.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * DARK CLIENT is a companion launcher/mod library for Minecraft Bedrock.
 * It does not inject code into Minecraft or modify game memory.
 */
public class MainActivity extends Activity {
    private static final int PICK_MOD = 4101;
    private static final String PREFS = "dark_client";
    private static final String KEY_MODS = "mods";
    private static final String MINECRAFT_PACKAGE = "com.mojang.minecraftpe";
    private final int BG = Color.rgb(10, 13, 20);
    private final int PANEL = Color.rgb(20, 26, 37);
    private final int ACCENT = Color.rgb(80, 220, 170);
    private LinearLayout content;
    private SharedPreferences prefs;
    private final ArrayList<ModItem> mods = new ArrayList<>();

    static class ModItem {
        String name, uri;
        ModItem(String n, String u) { name=n; uri=u; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadMods();
        showHome();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private void base(String subtitle) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = column();
        page.setPadding(20, 22, 20, 28);
        page.setBackgroundColor(BG);
        scroll.addView(page);
        setContentView(scroll);

        LinearLayout brand = row();
        TextView mark = text("D", 25, BG, true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(shape(ACCENT, 15));
        brand.addView(mark, new LinearLayout.LayoutParams(48,48));
        LinearLayout titles = column();
        titles.setPadding(12,0,0,0);
        titles.addView(text("DARK CLIENT", 20, Color.WHITE, true));
        titles.addView(text("BEDROCK COMPANION  •  v1.0", 10, ACCENT, true));
        brand.addView(titles, new LinearLayout.LayoutParams(0,-2,1));
        page.addView(brand);
        TextView sub = text(subtitle, 13, 0xFF9BA8BC, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2);
        sp.topMargin=18; sp.bottomMargin=16;
        page.addView(sub,sp);

        content = page;
        LinearLayout nav = row();
        nav.setPadding(10,8,10,8);
        nav.setBackground(shape(PANEL,18));
        addNav(nav,"HOME", v->showHome());
        addNav(nav,"MODS", v->showMods());
        addNav(nav,"SETTINGS", v->showSettings());
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1,-2);
        np.topMargin=22;
        page.addView(nav,np);
    }

    private void addNav(LinearLayout nav, String label, View.OnClickListener click) {
        TextView b=text(label,11,Color.WHITE,true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(10,13,10,13);
        nav.addView(b,new LinearLayout.LayoutParams(0,-2,1));
        b.setOnClickListener(click);
    }

    private void card(String title, String body) {
        LinearLayout c=column();
        c.setPadding(16,16,16,16);
        c.setBackground(shape(PANEL,18));
        c.addView(text(title,16,Color.WHITE,true));
        TextView desc=text(body,13,0xFFB0BBCB,false);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.topMargin=8; c.addView(desc,p);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);
        cp.topMargin=10; content.addView(c,cp);
    }

    private void button(String label, View.OnClickListener action) {
        TextView b=text(label,14,BG,true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(16,15,16,15);
        b.setBackground(shape(ACCENT,15));
        b.setOnClickListener(action);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.topMargin=12; content.addView(b,p);
    }

    private void showHome() {
        base("Your Bedrock toolkit. Simple, clean, and built for Android.");
        LinearLayout hero=column();
        hero.setPadding(18,22,18,22);
        hero.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF153B39,0xFF172333}));
        hero.setCornerRadius(22);
        hero.addView(text("PLAY YOUR WAY",12,ACCENT,true));
        TextView headline=text("Your Minecraft hub.",27,Color.WHITE,true);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);
        hp.topMargin=9; hero.addView(headline,hp);
        TextView copy=text("Launch Bedrock, organize add-ons, and keep your toolkit in one place.",14,0xFFD0D9E6,false);
        hp=new LinearLayout.LayoutParams(-1,-2); hp.topMargin=7; hero.addView(copy,hp);
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,-2);
        ep.topMargin=8; content.addView(hero,ep);

        card("MOD LIBRARY",mods.size()+" imported item(s) saved in your local library.");
        button("＋  IMPORT .MCPACK / .MCADDON / .MCWORLD",v->pickMod());
        button("▶  LAUNCH MINECRAFT BEDROCK",v->launchMinecraft());
        card("PERFORMANCE CHECKLIST","• Close background apps before playing\n• Keep enough free storage for worlds\n• Use a texture pack suited to your device\n• Lower render distance if FPS drops");
        card("SAFE BY DESIGN","DARK CLIENT is a companion launcher. Add-ons are handed to Minecraft through Android's file-opening system. No game-memory injection or account data collection.");
    }

    private void showMods() {
        base("Import and open your Bedrock add-ons and worlds.");
        button("＋  IMPORT FILE",v->pickMod());
        if(mods.isEmpty()) {
            card("NO ADD-ONS YET","Tap Import File and choose a .mcpack, .mcaddon, or .mcworld file.");
        } else {
            for(int i=0;i<mods.size();i++) {
                final int index=i;
                ModItem item=mods.get(i);
                LinearLayout c=column(); c.setPadding(14,14,14,14); c.setBackground(shape(PANEL,16));
                c.addView(text(item.name,14,Color.WHITE,true));
                TextView open=text("OPEN WITH MINECRAFT  ↗",11,ACCENT,true);
                TextView remove=text("REMOVE FROM LIBRARY",11,0xFFFF8B8B,true);
                LinearLayout actions=row();
                actions.addView(open,new LinearLayout.LayoutParams(0,-2,1));
                actions.addView(remove);
                LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2); ap.topMargin=12;
                c.addView(actions,ap);
                open.setOnClickListener(v->openMod(item));
                remove.setOnClickListener(v->{mods.remove(index);saveMods();showMods();});
                LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.topMargin=10;
                content.addView(c,cp);
            }
        }
        card("SUPPORTED FILES",".mcpack = resource/behavior pack\n.mcaddon = add-on bundle\n.mcworld = world backup");
    }

    private void showSettings() {
        base("Application information and compatibility.");
        card("MINECRAFT PACKAGE",MINECRAFT_PACKAGE);
        card("ANDROID STORAGE","The Android document picker grants access only to the file you select. Imported entries are remembered locally as document URIs.");
        card("COMPATIBILITY","Requires Minecraft Bedrock installed. Android and Minecraft versions may handle file associations differently.");
        card("ABOUT","DARK CLIENT v1.0.0\nUnofficial community companion. Not affiliated with or endorsed by Mojang or Microsoft.");
        button("CHECK MINECRAFT INSTALLATION",v->{
            if(getPackageManager().getLaunchIntentForPackage(MINECRAFT_PACKAGE)!=null)
                toast("Minecraft Bedrock is installed.");
            else toast("Minecraft Bedrock was not detected.");
        });
    }

    private void pickMod() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/octet-stream","application/zip","*/*"});
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(i,PICK_MOD); }
        catch(ActivityNotFoundException e) { toast("No file picker found on this device."); }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_MOD && resultCode==RESULT_OK && data!=null && data.getData()!=null) {
            Uri uri=data.getData();
            String name=queryName(uri);
            String lower=name.toLowerCase();
            if(!(lower.endsWith(".mcpack")||lower.endsWith(".mcaddon")||lower.endsWith(".mcworld"))) {
                toast("Choose a .mcpack, .mcaddon, or .mcworld file.");
                return;
            }
            try { getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch(Exception ignored) {}
            boolean exists=false;
            for(ModItem m:mods) if(m.uri.equals(uri.toString())) exists=true;
            if(!exists) mods.add(new ModItem(name,uri.toString()));
            saveMods();
            toast("Added to DARK CLIENT library.");
            showMods();
        }
    }

    private String queryName(Uri uri) {
        Cursor c=null;
        try {
            c=getContentResolver().query(uri,null,null,null,null);
            if(c!=null && c.moveToFirst()) {
                int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if(ix>=0) return c.getString(ix);
            }
        } catch(Exception ignored) { }
        finally { if(c!=null)c.close(); }
        return "Bedrock add-on";
    }

    private void openMod(ModItem item) {
        try {
            Uri uri=Uri.parse(item.uri);
            String n=item.name.toLowerCase();
            String mime=n.endsWith(".mcworld")?"application/x-mcworld":"application/octet-stream";
            Intent i=new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri,mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i,"Open with Minecraft"));
        } catch(ActivityNotFoundException e) {
            toast("No compatible app found. Try opening the file from your file manager.");
        } catch(Exception e) { toast("Could not open this file."); }
    }

    private void launchMinecraft() {
        Intent launch=getPackageManager().getLaunchIntentForPackage(MINECRAFT_PACKAGE);
        if(launch==null) { toast("Minecraft Bedrock is not installed."); return; }
        try { startActivity(launch); }
        catch(Exception e) { toast("Minecraft could not be started."); }
    }

    private void loadMods() {
        mods.clear();
        try {
            JSONArray a=new JSONArray(prefs.getString(KEY_MODS,"[]"));
            for(int i=0;i<a.length();i++) {
                JSONObject o=a.getJSONObject(i);
                mods.add(new ModItem(o.getString("name"),o.getString("uri")));
            }
        } catch(Exception ignored) { }
    }

    private void saveMods() {
        JSONArray a=new JSONArray();
        try {
            for(ModItem m:mods) {
                JSONObject o=new JSONObject(); o.put("name",m.name); o.put("uri",m.uri); a.put(o);
            }
            prefs.edit().putString(KEY_MODS,a.toString()).apply();
        } catch(Exception ignored) { }
    }

    private void toast(String message) { Toast.makeText(this,message,Toast.LENGTH_LONG).show(); }
}
