# DARK CLIENT — Minecraft Bedrock companion

An Android launcher and local add-on library for Minecraft Bedrock.

## MVP features
- Launch installed Minecraft Bedrock (`com.mojang.minecraftpe`)
- Import `.mcpack`, `.mcaddon`, and `.mcworld` through Android's Storage Access Framework
- Save selected document URIs locally
- Open imported files with Android's app chooser so Minecraft can handle the import
- Basic performance checklist and compatibility information

## Important scope
This is a **companion launcher**, not a modified Minecraft client. It does not inject code, patch Minecraft, modify game memory, bypass licensing, or provide cheats. Add-on import depends on Android/Minecraft file association behavior and may vary by version/device.

## Build APK with GitHub Actions (no PC required)
1. Create a new GitHub repository named `DARK-CLIENT`.
2. Upload the contents of this project ZIP to the repository root (not the ZIP file itself).
3. Commit to `main`.
4. Open the repository's **Actions** tab.
5. Select **Build DARK CLIENT APK** and wait for the workflow to finish.
6. Open the completed run, scroll to **Artifacts**, and download `DARK-CLIENT-debug`.
7. Extract the artifact ZIP; it contains `app-debug.apk`. Install it on your Android phone.

You can also run the workflow manually with **Actions → Build DARK CLIENT APK → Run workflow**.

## Technical details
- Native Android Java
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- JDK 17
- minSdk 23 / targetSdk 35
- No third-party runtime dependencies

## Project structure
```text
DARK-CLIENT/
├── .github/workflows/android.yml
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       └── java/com/darkclient/launcher/MainActivity.java
├── build.gradle
├── gradle.properties
├── settings.gradle
└── README.md
```

## Package
`com.darkclient.launcher`

## Troubleshooting
- If Minecraft is not detected, install the official Minecraft Bedrock app and check its package availability.
- If an add-on does not open directly, use your file manager's **Open with** action and select Minecraft.
- GitHub Actions build logs are available in the failed workflow run.
- The first GitHub Actions run downloads the Android Gradle Plugin and Android SDK components, so it may take several minutes.

## Disclaimer
Minecraft is a trademark of Mojang Studios. DARK CLIENT is an independent, unofficial companion project and is not affiliated with Mojang or Microsoft.
